<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class contactinfoModel extends Model
{
    use HasFactory;
    // Table name
    protected $table = 'beheerderinfo';
    
    // Product key
    public $primaryKey = 'id';
}
