<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class verhuurModel extends Model
{
    use HasFactory;
    // Table name
    protected $table = 'reserveringen';
    
    // Product key
    public $primaryKey = 'id';
}   
