<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class mijnresModel extends Model
{
    use HasFactory;
    protected $table = 'reserveringen';
    
    // Product key
    public $primaryKey = 'id';
}
