<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use DateTime;
use App\Models\verhuurModel;
use App\Models\infoModel;

class verhuurController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('/verhuur');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $this->validate($request, [
            'begindatum' => 'required',
            'einddatum' => 'required',
            'personen' => 'required',
            'linnengoed' => 'required',
        ]); 
        // user id opvragen
        $userid = Auth::user()->id;

        // verschil van datum
        $fdate = $request->input('begindatum');
        $tdate = $request->input('einddatum');
        $datetime1 = new DateTime($fdate);
        $datetime2 = new DateTime($tdate);
        $interval = $datetime1->diff($datetime2);
        $days = $interval->format('%a');

        //prijs berekenen
        $prijs = infoModel::pluck('huisjeprijs')->first();
        $kosten = $days * $prijs * $request->input('personen');
        
        //Nieuw product toevoegen
        $reservering = new verhuurModel;
        $reservering->huurdernr = $userid;
        $reservering->datumverschil = $days;
        $reservering->kosten = $kosten;
        $reservering->begindatum = $request->input('begindatum');
        $reservering->einddatum = $request->input('einddatum');
        $reservering->aantal_personen = $request->input('personen');
        $reservering->linnengoed = $request->input('linnengoed');
        $reservering->save();

        return redirect('/verhuur') ->with('Success', 'Reservering is geplaats!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
