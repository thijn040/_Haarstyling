
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Acties</title>
</head>
<body>
<style>
body{
  font-family: "Times New Roman";
  background-image: url('{{ asset('assets/Kapper.jpg') }}');
  background-repeat: no-repeat;
  color: white;
  border-color: lightgray;
}
img {
  border: 5px solid #555;
}
img[id="logo"]{
  border: 5px solid lightgray;
}
.site-footer
{
  background-color:#26272b;
  padding:45px 0 20px;
  font-size:15px;
  line-height:24px;
  color:#737373;
  border-top: 5px solid black;
}
.site-footer hr
{
  border-top-color:#bbb;
  opacity:0.5
}
.site-footer hr.small
{
  margin:20px 0
}
.site-footer h6
{
  color:#fff;
  font-size:16px;
  text-transform:uppercase;
  margin-top:5px;
  letter-spacing:2px
}
.site-footer a
{
  color:#737373;
}
.site-footer a:hover
{
  color:#3366cc;
  text-decoration:none;
}
.footer-links
{
  padding-left:0;
  list-style:none
}
.footer-links li
{
  display:block
}
.footer-links a
{
  color:#737373
}
.footer-links a:active,.footer-links a:focus,.footer-links a:hover
{
  color:#3366cc;
  text-decoration:none;
}
.footer-links.inline li
{
  display:inline-block
}
.site-footer .social-icons
{
  text-align:right
}
.site-footer .social-icons a
{
  width:40px;
  height:20px;
  line-height:20px;
  margin-left:6px;
  margin-right:0;
  border-radius:100%;
  background-color:#33353d
}
.copyright-text
{
  margin:0
}
@media (max-width:991px)
{
  .site-footer [class^=col-]
  {
    margin-bottom:30px
  }
}
@media (max-width:767px)
{
  .site-footer
  {
    padding-bottom:0
  }
  .site-footer .copyright-text,.site-footer .social-icons
  {
    text-align:center
  }
}
.social-icons
{
  padding-left:0;
  margin-bottom:0;
  list-style:none
}
.social-icons li
{
  display:inline-block;
  margin-bottom:4px
}
.social-icons li.title
{
  margin-right:15px;
  text-transform:uppercase;
  color:#96a2b2;
  font-weight:700;
  font-size:13px
}
.social-icons a{
  background-color:#eceeef;
  color:#818a91;
  font-size:16px;
  display:inline-block;
  line-height:44px;
  width:44px;
  height:44px;
  text-align:center;
  margin-right:8px;
  border-radius:100%;
  -webkit-transition:all .2s linear;
  -o-transition:all .2s linear;
  transition:all .2s linear
}
.social-icons a:active,.social-icons a:focus,.social-icons a:hover
{
  color:#fff;
  background-color:#29aafe
}
.social-icons.size-sm a
{
  line-height:34px;
  height:34px;
  width:34px;
  font-size:14px
}
.social-icons a.facebook:hover
{
  background-color:#3b5998
}
.social-icons a.twitter:hover
{
  background-color:#00ce45
}
.social-icons a.linkedin:hover
{
  background-color:#007bb6
}
.social-icons a.dribbble:hover
{
  background-color:#ea4c89
}
@media (max-width:767px)
{
  .social-icons li.title
  {
    display:block;
    margin-right:0;
    font-weight:600
  }
}
</style>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a href="homepagina"><img id="logo" src="{{ asset('assets/Logo.png') }}" alt="Image Load Error" width="150" height="100"></a>
    <div class="collapse navbar-collapse">
    <div class="float-right">
        <ul class="navbar-nav">
        <a class="nav-link" href="homepagina">Home pagina</a>  
            <a class="nav-link" href="Producten_prijzen">Producten & prijzen</a>
            <a class="nav-link" href="galerij">Galerij</a>
            <a class="nav-link" href="acties">Acties</a>
            <a class="nav-link" href="contact">Contact</a>
            @if (Auth::guest())
                            <li><a class="nav-link" href="{{ route('login') }}">Login</a></li>
                        @else
                            
                                    <li>
                                        <a class="nav-link" href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                
                        @endif  
        @yield('content')
    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
            </ul>
          </div>
        </ul>
    </div>
    </div>
</nav>
<h1>Acties</h1>
@if (Auth::guest())
                            
                        @else
                            
                        <a class="nav-link" href="editActiesPagina">Edit</a>
                                
                        @endif  
        
<h5>Op deze pagina vind je de prijslijst:</h5>
<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Product</th>
      <th scope="col"></th>
      <th scope="col">Prijs</th>
      <th scope="col">Prijs met korting</th>
    </tr>
  </thead>
  <tbody> 
<?php foreach ($acties as $m)
{ ?>
<tr>
      <th scope="row">{{ $actieid = $m->actieId }}</th>
      <th style="width: 50px;"><img src="{{ asset('assets/goldwell color.jpg') }}" alt="Foto1" style="width:100%;"></th>
      <td>{{ $actieproduct = $m->actieProduct }}</td>
      <td>{{ $prijs = $m->prijs }}</td>
      <td>{{ $prijsmetkorting = $m->prijsMetKorting }}</td>
</tr>
<?php 
} ?>
</tbody>
</table>
<footer class="site-footer">
      <div class="container">
        <div class="row">
        <div class="col-xs-6 col-md-3">
            <h6>Contact</h6>
            <ul class="footer-links">
              <li><a href="https://wa.me/+31619827034">Whatsapp</a></li>
              <li><a href="https://www.facebook.com/Liannes-haarstyling-101793808179858/">Facebook</a></li>
            </ul>
          </div>

          

          <div class="col-xs-6 col-md-3">
            <h6>Snel Navigeren</h6>
            <ul class="footer-links">
                <li><a href="homepagina">Home pagina</a></li>
                <li><a href="Producten_prijzen">Producten en prijzen</a></li>
                <li><a href="galerij">Gallerij</a></li>
                <li><a href="acties">Acties</a></li>
                <li><a href="contactpagina">Contact</a></li>
                

      <div id="fb-root"></div>
      <script async defer crossorigin="anonymous" src="https://connect.facebook.net/nl_NL/sdk.js#xfbml=1&version=v9.0" nonce="vYo4Z1jU"></script>
      <div class="fb-page"  data-href="https://www.facebook.com/Liannes-haarstyling-101793808179858/" data-tabs="timeline" data-width="650" data-height="300" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/Liannes-haarstyling-101793808179858/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/Liannes-haarstyling-101793808179858/">Lianne&#039;s haarstyling</a></blockquote>
      </div>
 
    </div>
        <hr>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; 2020 Angel Kovani en Thijn Senden
            </p>
          </div>
          

          <div class="col-md-4 col-sm-6 col-xs-12">
            <ul class="social-icons">
              <li><a class="facebook" href="https://www.facebook.com/Liannes-haarstyling-101793808179858/"><i class="fa fa-facebook"></i></a></li>
              <li><a class="twitter" href="https://wa.me/+31619827034"><i class="fa fa-whatsapp"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
</footer>
</body>
</html>

