<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConModel extends Model
{
    protected $table = 'websiteinhoud';
    public $timestamps = false;
    protected $primaryKey = "InhoudId"; 
}
