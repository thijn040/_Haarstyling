<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActieModel extends Model
{
    protected $table = 'acties';
    public $timestamps = false;
    protected $primaryKey = "actieId"; 
}
