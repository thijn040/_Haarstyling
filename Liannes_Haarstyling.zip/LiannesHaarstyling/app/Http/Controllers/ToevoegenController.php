<?php

namespace App\Http\Controllers;

use App\ActieModel;
use App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class ToevoegenController extends Controller
{
    public function detail4(Request $request)
    {
        $acties = DB::table('acties')->get();
        return view('editActiesPagina', array('acties'=>$acties));
    }
        
        public function update(Request $request,$id) 
        {
        $actieProduct = $request->input('actieProduct');
        $Prijs = $request->input('prijs');
        $prijsmetKorting = $request->input('prijsMetKorting');
        $actie = ActieModel::find($id);


        $actie->actieProduct = $request->input('actieProduct');
        $actie->prijs = $request->input('Prijs');
        $actie->prijsMetKorting = $request->input('prijsMetKorting');
        // $product->img_path = $fileNameToStore;
        $actie->save();

        DB::update('update acties set actieProduct = ?,prijs=?, prijsMetKorting=? where actieId = ?',[$actieProduct, $Prijs ,$prijsmetKorting ,$id]);
        return back(); 
        }
}
