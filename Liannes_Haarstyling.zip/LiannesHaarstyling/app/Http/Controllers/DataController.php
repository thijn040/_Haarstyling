<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ConModel;
use App\ProductModel;
use App\Http\Controllers;
use Illuminate\Support\Facades\DB;

class DataController extends Controller
{
    public function detail(Request $request)
    {
       $data = ConModel::where('InhoudId', '1')->get();
       $data2 = ConModel::where('InhoudId', '2')->get();
              
       return view('homepagina', array('data'=>$data, 'data2'=>$data2));
    }

    public function detail2(Request $request)
    {

        $verzorgingsProducten = ProductModel::where('productCatagorie', 'verzorgingsproduct')->paginate(4);
        $stylingsProducten = ProductModel::where('productCatagorie', 'stylingsproduct')->paginate(4);
        return view('Producten_prijzen')->with('verzorgingsProducten',$verzorgingsProducten)->with('stylingsProducten',$stylingsProducten);
    }
    public function detail3(Request $request)
    {
        $acties = DB::table('acties')->get();
        return view('acties', array('acties'=>$acties));
    }
    
   
}
