<?php

namespace App\Http\Controllers;

use App\ConModel;
use App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class HomeAanpassenController extends Controller
{
    public function detail5(Request $request)
    {
        $inhoud = DB::table('websiteinhoud')->get();
        return view('editHomePagina', array('websiteinhoud'=>$inhoud));
    }
    
        public function update(Request $request,$id) 
        {
        $homePaginaInhoud = $request->input('paginaInhoud');
        
        $home = ConModel::find($id);


        $home->HomePaginaInhoud = $request->input('paginaInhoud');
        // $product->img_path = $fileNameToStore;
        $home->save();

        DB::update('update websiteinhoud set HomePaginaInhoud = ? where InhoudId = ?',[$homePaginaInhoud ,$id]);
        return back(); 
        }
}
