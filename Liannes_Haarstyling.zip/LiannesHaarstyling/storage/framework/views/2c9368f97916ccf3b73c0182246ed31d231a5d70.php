
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Verzorgingsproducten & Styling producten</title>
</head>
<body style="font-family: times-new-roman;">
<style>
body{
  font-family: "Times New Roman";
  background-image: url('<?php echo e(asset('assets/Kapper.jpg')); ?>');
  background-repeat: no-repeat;
  color: white;
  border-color: lightgray;
}

img {
  border: 5px solid #555;
}
img[id="logo"]{
  border: 5px solid lightgray;
}

</style>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a href="homepagina"><img id="logo" src="<?php echo e(asset('assets/Logo.png')); ?>" alt="Image Load Error" width="150" height="100"></a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
            <a class="nav-link" href="homepagina">Home pagina</a>  
            <a class="nav-link" href="Producten_prijzen" id="active">Producten & prijzen</a>
            <a class="nav-link" href="galerij">Galerij</a>
            <a class="nav-link" href="acties">Acties</a>
            <a class="nav-link" href="contact">Contact</a>
            <?php if(Auth::guest()): ?>
                            <li><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php else: ?>
                            
                                    <li>
                                        <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                
                        <?php endif; ?>  
        <?php echo $__env->yieldContent('content'); ?>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </ul>
  </div>
</nav>
<h1>Verzorgingsproducten:</h1>
<?php if(count($verzorgingsProducten) > 0): ?>
<?php $__currentLoopData = $verzorgingsProducten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <div style="
  float:left;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  display: inline-block;">
  <p><img src="<?php echo e(asset('assets/goldwell color.jpg')); ?>" alt="Foto1" style="width:40%;"></p>
  <p style="font-weight: bold;"><h5><?php echo e($m->productNaam); ?></h5><br><p style="color:crimson; font-weight:bold;"></p></p>
  <p><?php echo e($m->productBeschrijving); ?></p>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</div>
<div class="row">
  <div>
  <?php echo e($verzorgingsProducten->links()); ?>

  </div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<h1>Stylingsproducten:</h1>
<?php if(count($stylingsProducten) > 0): ?>
<?php $__currentLoopData = $stylingsProducten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <div style="
  float:left;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  display: inline-block;
  background: lightgray;">
  <p><img src="<?php echo e(asset('assets/goldwell color.jpg')); ?>" alt="Foto1" style="width:40%;"></p>
  <p style="font-weight: bold;"><h5><?php echo e($m->productNaam); ?></h5><br><p style="color:crimson; font-weight:bold;"></p></p>
  <p><?php echo e($m->productBeschrijving); ?></p>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</div>
<div class="row">
  <div>
  <?php echo e($stylingsProducten->links()); ?>

  </div>
</div>


</body>
</html>

