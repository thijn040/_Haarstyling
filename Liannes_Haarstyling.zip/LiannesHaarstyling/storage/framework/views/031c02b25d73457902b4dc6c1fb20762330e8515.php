
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Login</title>
</head>
<body>
<style>
body{
  font-family: "Times New Roman";
  background-image: url('<?php echo e(asset('assets/Kapper.jpg')); ?>');
  background-repeat: no-repeat;
  color: white;
  border-color: lightgray;
}
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  height: 10%;
  width: 100%;
  background-color: lightgray;
  color: white;
  text-align: center;
}
.centered {
    position: absolute;
    top: 50%;
    left: 12%;
    transform: translate(-50%, -50%);
}
img {
  border: 5px solid #555;
}
img[id="logo"]{
  border: 5px solid lightgray;
}
</style>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a href="homepagina"><img id="logo" src="<?php echo e(asset('assets/Logo.png')); ?>" alt="Image Load Error" width="150" height="100"></a>
    <div class="collapse navbar-collapse">
    <div class="float-right">
        <ul class="navbar-nav">
        <a class="nav-link" href="homepagina">Home pagina</a>  
            <a class="nav-link" href="Producten_prijzen">Producten & prijzen</a>
            <a class="nav-link" href="galerij">Galerij</a>
            <a class="nav-link" href="acties">Acties</a>
            <a class="nav-link" href="contact">Contact</a>
            <a class="nav-link" href="login">Login</a>
        </ul>
    </div>
    </div>
</nav>
<script>
function myFunction() {
  var x = document.getElementById("wachtwoord");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
<div class="centered">
<h1>Login</h1>
<form>
                <div class="form-group">
                    <label>Email address</label>
                    <input type="email" class="form-control" aria-describedby="emailHelp" placeholder="Email">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" id="wachtwoord" placeholder="Wachtwoord">
                </div>
                <div class="form-check">
                    <input type="checkbox" onclick="myFunction()" class="form-check-input">
                    <label class="form-check-label">Wachtwoord Tonen</label>
                </div>
                    <button type="submit" class="btn btn-primary">Doorgaan</button>
</form> 
</div>

<div class="footer">
<p>Telefoonnummer: 06-19827034</p>
  <p>Mijn Facebook: <a href="https://www.facebook.com/pages/category/Barber-Shop/Liannes-haarstyling-101793808179858/" class="fa fa-facebook"></a></p>
  
</div>
</body>
</html>

