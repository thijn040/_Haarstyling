<?php
use App\Http\Controllers\Auth\LoginController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/homepagina', 'DataController@detail', 'HomeController@index');

Route::get('logout', [LoginController::class, 'logout']);

Route::get('/Producten_prijzen', 'DataController@detail2');

Route::get('/acties', 'DataController@detail3');
        
Route::get('/galerij', function (){
    return view('galerij');
    });
Route::get('/contact', function (){
    return view('contactpagina');
    });    

Route::get('/login', function (){
    return view('login');
    });
Route::get('/editActiesPagina', 'ToevoegenController@detail4');
Route::get('/editHomePagina', 'HomeAanpassenController@detail5');

Auth::routes();

route::resource('actie', 'ToevoegenController', ['only'=>['update']]);
route::resource('homepagina', 'HomeAanpassenController', ['only'=>['update']]);
